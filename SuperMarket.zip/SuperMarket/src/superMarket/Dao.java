package superMarket;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.Scanner;

public class Dao {
	private static Scanner sc = new Scanner(System.in);
	private static final String url = "jdbc:mysql://127.0.0.1:3306/supermarket";
	private static final String pwd = "root123";
	private static final String user = "root";
	private static Connection getConnection() {
		try {
			Connection conn = DriverManager.getConnection(url,user,pwd);
			return conn;
		}catch(Exception e) {
			e.printStackTrace();
		}
		return null;
	}
	public static boolean Add(Users u) {
		try {
			String sql = "INSERT INTO users(fname,email,pwd,roles) VALUE(?,?,?,?);";
			PreparedStatement ps = getConnection().prepareStatement(sql);
			ps.setString(1,u.getFname());
			ps.setString(2,u.getEmail());
			ps.setString(3,u.getPwd());
			ps.setString(4,u.getRoles());
			int ar = ps.executeUpdate();
			if(ar>0)
				return true;
			else
				return false;
		}catch(Exception e) {
			e.printStackTrace();
		}
		return false;
	}
	public static Users CheckUser(String email,String pwd) {
		try {
			Users u = new Users();
			String sql = "SELECT * FROM users WHERE email=? AND pwd=?;";
			PreparedStatement ps = getConnection().prepareStatement(sql);
			ps.setString(1, email);
			ps.setString(2, pwd);
			ResultSet rs = ps.executeQuery();
			if(rs.next()) {
				u.setUid(rs.getInt(1));
				u.setFname(rs.getString(2));
				u.setEmail(rs.getString(3));
				u.setPwd(rs.getString(4));
				u.setRoles(rs.getString(5));
			}
			return u;
		}catch(Exception e) {
			e.printStackTrace();
		}
		return null;
	}
}