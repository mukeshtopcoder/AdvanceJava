package superMarket;
import java.util.Scanner;
public class Users {
	private int uid;
	private String fname;
	private String email;
	private String pwd;
	private String roles;
	private static Scanner sc = new Scanner(System.in);
	public static void Login(String roles) {
		System.out.print("Enter Email ID : ");
		String email = sc.next();
		System.out.print("Enter Password : ");
		String pwd = sc.next();
		Users u = Dao.CheckUser(email,pwd);
		if(u!=null) {
			System.out.println(u.getFname());
		}else {
			System.out.println("User is Not Available");
		}
	} 
	public static void AddUser(String roles) {
		System.out.print("Enter First Name : ");
		String fname = sc.next();
		System.out.print("Enter Email : ");
		String email = sc.next();
		System.out.print("Enter Password : ");
		String pwd = sc.next();
		Users u = new Users(fname,email,pwd,roles);
		if(Dao.Add(u)) {
			System.out.println("Customer Added Success!");
			System.out.println("Welcome! "+u.getFname());
		}else {
			System.out.println("Failed To Add Customer!");
		}
	}
	public Users(String fname, String email, String pwd, String roles) {
		super();
		this.fname = fname;
		this.email = email;
		this.pwd = pwd;
		this.roles = roles;
	}
	public Users() {
		super();
	}
	public int getUid() {
		return uid;
	}
	public void setUid(int uid) {
		this.uid = uid;
	}
	public String getFname() {
		return fname;
	}
	public void setFname(String fname) {
		this.fname = fname;
	}
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	public String getPwd() {
		return pwd;
	}
	public void setPwd(String pwd) {
		this.pwd = pwd;
	}
	public String getRoles() {
		return roles;
	}
	public void setRoles(String roles) {
		this.roles = roles;
	}
}